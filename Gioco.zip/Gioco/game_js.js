document.addEventListener('DOMContentLoaded', function() {
  var personaggio = document.getElementById('Personaggio');
  var areaDiGioco = document.getElementById('AreaDiGioco');
  var vite = 3;
  var monete = 0;
  var punteggio = 0;
  var intervalloNemici = null;
  var intervalloMonete = null;
  var ultimaPosizioneX = null; // Variabile per tenere traccia dell'ultima posizione X del personaggio
  var suono;

  // Avvia il gioco
  iniziaGioco();

  function iniziaGioco() {
    // Avvia l'intervallo per la creazione dei nemici
    intervalloNemici = setInterval(creaNemico, 1000);

    // Avvia l'intervallo per la creazione delle monete
    intervalloMonete = setInterval(creaMoneta, 3000);

    // Avvia l'intervallo per aumentare il punteggio
    setInterval(aggiornaPunteggio, 1000);

    areaDiGioco.addEventListener('mousemove', function(event) {

      // Ottieni le coordinate del mouse rispetto all'area di gioco
      var mouseX = event.clientX - areaDiGioco.getBoundingClientRect().left;
      var mouseY = event.clientY - areaDiGioco.getBoundingClientRect().top;

      // Imposta la posizione del personaggio in base alle coordinate del mouse
      personaggio.style.left = mouseX - personaggio.offsetWidth / 2 + 'px';
      personaggio.style.top = mouseY - personaggio.offsetHeight / 2 + 'px';

      // Cambia immagine del personaggio a seconda del movimento
      if (ultimaPosizioneX !== null) {
        if (mouseX > ultimaPosizioneX) {
          personaggio.src = "./Img/pg1.gif"; // Immagine per il movimento verso destra
        } else if (mouseX < ultimaPosizioneX) {
          personaggio.src = "./Img/pg2.gif"; // Immagine per il movimento verso sinistra
        }
      }
      ultimaPosizioneX = mouseX; // Aggiorna l'ultima posizione X
    });
  }

  function creaNemico() {
    var nemico = document.createElement('img');
    nemico.classList.add('nemico');
    
    // Genera casualmente la velocità lungo l'asse X
    var velocitaX = Math.random() * 6 - 3;

    // Scegli l'immagine in base alla direzione del movimento
    if (velocitaX > 0) {
        nemico.src = "./Img/piccionedx.gif"; // Immagine per la destra
    } else {
        nemico.src = "./Img/piccionesx.gif"; // Immagine per la sinistra
    }

    nemico.style.position = 'absolute';

    // Genera casualmente la posizione iniziale X e Y del nemico
    var posizioneInizialeX = Math.random() * (areaDiGioco.offsetWidth - 50);
    var posizioneInizialeY = areaDiGioco.offsetHeight; // Inizia dal basso dell'area di gioco

    // Imposta la posizione iniziale del nemico
    nemico.style.left = posizioneInizialeX + 'px';
    nemico.style.top = posizioneInizialeY + 'px';

    // Aggiungi il nemico all'area di gioco
    areaDiGioco.appendChild(nemico);

    // Velocità verso l'alto
    var velocitaY = -2;

    // Movimento del nemico
    var movimentoNemico = setInterval(function() {
        // Calcola la nuova posizione del nemico
        var nuovaPosizioneX = nemico.offsetLeft + velocitaX;
        var nuovaPosizioneY = nemico.offsetTop + velocitaY;

        // Aggiorna la posizione del nemico
        nemico.style.left = nuovaPosizioneX + 'px';
        nemico.style.top = nuovaPosizioneY + 'px';

        // Rimuovi il nemico quando esce dall'area di gioco
        if (nuovaPosizioneY < -50) {
            nemico.remove();
            clearInterval(movimentoNemico);
        }

        // Verifica la collisione con il personaggio
        if (controllaCollisione(personaggio, nemico)) {
            nemico.remove();
            clearInterval(movimentoNemico);

            // suono danno

            suono = document.getElementById("danno");
            suono.play();

            aggiornaVite();
        }
    }, 30); // Ogni 30 millisecondi
  }

  function creaNemicoVeloce() { // aquila
    var nemico = document.createElement('img');
    nemico.classList.add('nemico');
    nemico.src = "./Img/aquila.gif"; // Percorso dell'immagine
    nemico.style.position = 'absolute';

    // Genera casualmente la posizione iniziale X e Y del nemico
    var posizioneInizialeX = Math.random() * (areaDiGioco.offsetWidth - 50);
    var posizioneInizialeY = areaDiGioco.offsetHeight; // Inizia dal basso dell'area di gioco

    // Imposta la posizione iniziale del nemico
    nemico.style.left = posizioneInizialeX + 'px';
    nemico.style.top = posizioneInizialeY + 'px';

    // Aggiungi il nemico all'area di gioco
    areaDiGioco.appendChild(nemico);

    // Velocità verso l'alto per il nemico veloce
    var velocitaY = -4;

    // Velocità casuale lungo l'asse X per il nemico veloce
    var velocitaX = Math.random() * 8 - 4;

    // Scegli l'immagine in base alla direzione del movimento
    if (velocitaX > 0) {
      nemico.src = "./Img/aquilaDX.gif"; // Immagine per la destra
    } else {
      nemico.src = "./Img/aquila.gif"; // Immagine per la sinistra
    }

    // Movimento del nemico
    var movimentoNemico = setInterval(function() {
        // Calcola la nuova posizione del nemico
        var nuovaPosizioneX = nemico.offsetLeft + velocitaX;
        var nuovaPosizioneY = nemico.offsetTop + velocitaY;

        // Aggiorna la posizione del nemico
        nemico.style.left = nuovaPosizioneX + 'px';
        nemico.style.top = nuovaPosizioneY + 'px';

        // Rimuovi il nemico quando esce dall'area di gioco
        if (nuovaPosizioneY < -50) {
            nemico.remove();
            clearInterval(movimentoNemico);
        }

        // Verifica la collisione con il personaggio
        if (controllaCollisione(personaggio, nemico)) {
          nemico.remove();
          clearInterval(movimentoNemico);
          aggiornaVite();
      }
    }, 30); // Ogni 30 millisecondi
  }

  function creaNemicoMoltoVeloce() {
    var nemico = document.createElement('img');
    nemico.classList.add('nemico');
    nemico.src = "./Img/c.gif"; // Percorso dell'immagine
    nemico.style.position = 'absolute';

    // Genera casualmente la posizione iniziale X e Y del nemico
    var posizioneInizialeX = Math.random() * (areaDiGioco.offsetWidth - 50);
    var posizioneInizialeY = areaDiGioco.offsetHeight; // Inizia dal basso dell'area di gioco

    // Imposta la posizione iniziale del nemico
    nemico.style.left = posizioneInizialeX + 'px';
    nemico.style.top = posizioneInizialeY + 'px';

    // Aggiungi il nemico all'area di gioco
    areaDiGioco.appendChild(nemico);

    // Velocità verso l'alto per il nemico molto veloce
    var velocitaY = -6;

    // Velocità casuale lungo l'asse X per il nemico molto veloce
    var velocitaX = Math.random() * 12 - 6;

    // Scegli l'immagine in base alla direzione del movimento
    if (velocitaX > 0) {
      nemico.src = "./Img/cDX.gif"; // Immagine per la destra
    } else {
      nemico.src = "./Img/c.gif"; // Immagine per la sinistra
    }

    // Movimento del nemico
    var movimentoNemico = setInterval(function() {
        // Calcola la nuova posizione del nemico
        var nuovaPosizioneX = nemico.offsetLeft + velocitaX;
        var nuovaPosizioneY = nemico.offsetTop + velocitaY;

        // Aggiorna la posizione del nemico
        nemico.style.left = nuovaPosizioneX + 'px';
        nemico.style.top = nuovaPosizioneY + 'px';

        // Rimuovi il nemico quando esce dall'area di gioco
        if (nuovaPosizioneY < -50) {
            nemico.remove();
            clearInterval(movimentoNemico);
        }

       // Verifica la collisione con il personaggio
       if (controllaCollisione(personaggio, nemico)) {
        nemico.remove();
        clearInterval(movimentoNemico);
        aggiornaVite();
    }
    }, 30); // Ogni 30 millisecondi
  }

  function creaMoneta() {
    // Decidi casualmente se creare una moneta normale o una rara
    var probabilitaMonetaRara = 0.1; // 10% di probabilità di creare una moneta rara
    var monetaRara = Math.random() < probabilitaMonetaRara;

    var moneta = document.createElement('img');
    if (monetaRara) {
      moneta.src = "./Img/Coin2.gif"; // Immagine per la moneta rara
      moneta.classList.add('moneta-rara');
    } else {
      moneta.src = "./Img/Coin.gif"; // Immagine per la moneta normale
      moneta.classList.add('moneta');
    }
    
    moneta.style.position = 'absolute';

    // Genera casualmente la posizione X della moneta
    var posizioneX = Math.random() * (areaDiGioco.offsetWidth - 50);

    // Imposta la posizione iniziale della moneta sopra l'area di gioco
    moneta.style.left = posizioneX + 'px';
    moneta.style.top = -50 + 'px';

    // Aggiungi la moneta all'area di gioco
    areaDiGioco.appendChild(moneta);

    // Movimento della moneta
    var movimentoMoneta = setInterval(function() {
        var posizioneMoneta = moneta.offsetTop;
        if (posizioneMoneta > areaDiGioco.offsetHeight) {
            moneta.remove();
            clearInterval(movimentoMoneta);
        } else {
            moneta.style.top = posizioneMoneta + 3 + 'px';
            if (controllaCollisione(personaggio, moneta)) {
                moneta.remove();
                clearInterval(movimentoMoneta);
                if (monetaRara) {
                    monete++;
                    punteggio += 200; // Aggiungi 100 punti per la moneta rara
                } else {
                    monete++;
                    punteggio += 55; // Aggiungi 5 punti per la moneta normale
                }
                aggiornaMonete();
                aggiornaPunteggio(); // Aggiorna il punteggio
            }
        }
    }, 30);
  }

  function controllaCollisione(personaggio, elemento) {
    var rectPersonaggio = personaggio.getBoundingClientRect();
    var rectElemento = elemento.getBoundingClientRect();
    return !(rectPersonaggio.right < rectElemento.left ||
             rectPersonaggio.left > rectElemento.right ||
             rectPersonaggio.bottom < rectElemento.top ||
             rectPersonaggio.top > rectElemento.bottom);
  }

  function aggiornaVite(numeroViteDaRimuovere) {
    if (numeroViteDaRimuovere === undefined) {
        numeroViteDaRimuovere = 1;
    }
    vite -= numeroViteDaRimuovere;
    if (vite === 0) {
        clearInterval(intervalloNemici);
        clearInterval(intervalloMonete);
        alert('Game Over');
        ripristinaGioco(); // Ricomincia il gioco

        suono = document.getElementById("morte");
        suono.play();
    }
  }

  function aggiornaMonete() {
    document.getElementById('monete').innerText = 'Monete: ' + monete;
    if (monete === 22) {
      punteggio += 22;
      vite++;
      monete = 0;
      document.getElementById('punteggio').innerText = 'Punteggio: ' + punteggio;
      
       // suono danno

       
        suono = document.getElementById("suonoMoneta");
        suono.play();

    }
  }

  function aggiornaPunteggio() {
    document.getElementById('punteggio').innerText = 'Punteggio: ' + punteggio;

    // Se il punteggio raggiunge 300, crea un nemico più veloce
    if (punteggio >= 300 && punteggio < 1000) {
        clearInterval(intervalloNemici); // Ferma l'intervallo attuale per la creazione dei nemici
        intervalloNemici = setInterval(creaNemicoVeloce, 700); // Avvia un nuovo intervallo con nemici più veloci
       // var sfondo = document.getElementById('AreaDiGioco');
       // sfondo.style.backgroundImage.src = './Img/cielo2.png';


    } else if (punteggio >= 1000) {
        clearInterval(intervalloNemici); // Ferma l'intervallo attuale per la creazione dei nemici veloci
        intervalloNemici = setInterval(creaNemicoMoltoVeloce, 500); // Avvia un nuovo intervallo con nemici molto veloci
    }
  }

  function ripristinaGioco() {
    vite = 3;
    monete = 0;
    punteggio = 0;
    document.getElementById('punteggio').innerText = 'Punteggio: ' + punteggio;
    document.getElementById('monete').innerText = 'Monete: ' + monete;
    iniziaGioco();
  }
});
